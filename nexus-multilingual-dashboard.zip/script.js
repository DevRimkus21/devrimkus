// Dictionnaire des traductions (FR / EN)
const translations = {
  fr: {
    nav_overview: "Vue d'ensemble",
    nav_projects: "Projets",
    nav_analytics: "Analytics",
    hero_welcome: "Bienvenue sur votre espace,",
    hero_subtitle: "Voici l'état d'avancement de vos projets et de vos performances actuelles.",
    btn_new_project: "Nouveau Projet",
    stat_active_projects: "Projets Actifs",
    stat_revenue: "Revenus",
    stat_time_saved: "Temps Économisé",
    tasks_header: "Tâches Prioritaires",
    btn_add: "Ajouter",
    task_1: "Refonte de la charte graphique",
    task_2: "Optimisation des performances CSS/JS",
    tag_design: "Design",
    tag_dev: "Dev",
    tag_new: "Nouveau",
    prompt_new_task: "Intitulé de la nouvelle tâche :",
    alert_project_created: "Nouveau projet créé avec succès !"
  },
  en: {
    nav_overview: "Overview",
    nav_projects: "Projects",
    nav_analytics: "Analytics",
    hero_welcome: "Welcome to your workspace,",
    hero_subtitle: "Here is the current progress of your projects and performance.",
    btn_new_project: "New Project",
    stat_active_projects: "Active Projects",
    stat_revenue: "Revenue",
    stat_time_saved: "Time Saved",
    tasks_header: "Priority Tasks",
    btn_add: "Add",
    task_1: "Redesign graphic chart",
    task_2: "CSS/JS performance optimization",
    tag_design: "Design",
    tag_dev: "Dev",
    tag_new: "New",
    prompt_new_task: "Enter new task title:",
    alert_project_created: "New project successfully created!"
  }
};

let currentLang = 'fr';

// Fonction de mise à jour de la langue
function updateLanguage(lang) {
  currentLang = lang;
  document.documentElement.lang = lang;
  
  const elements = document.querySelectorAll('[data-i18n]');
  elements.forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (translations[lang] && translations[lang][key]) {
      el.textContent = translations[lang][key];
    }
  });
}

// Écouteur pour le changement de langue
const langSelect = document.getElementById('lang-select');
langSelect.addEventListener('change', (e) => {
  updateLanguage(e.target.value);
});

// Theme Toggle (Dark / Light Mode)
const themeToggleBtn = document.getElementById('theme-toggle');
const icon = themeToggleBtn.querySelector('i');

themeToggleBtn.addEventListener('click', () => {
  const currentTheme = document.body.getAttribute('data-theme');
  if (currentTheme === 'light') {
    document.body.removeAttribute('data-theme');
    icon.className = 'fa-solid fa-moon';
  } else {
    document.body.setAttribute('data-theme', 'light');
    icon.className = 'fa-solid fa-sun';
  }
});

// Ajout dynamique de tâche
const addTaskBtn = document.getElementById('add-task-btn');
const taskList = document.getElementById('task-list');

addTaskBtn.addEventListener('click', () => {
  const taskText = prompt(translations[currentLang].prompt_new_task);
  if (taskText && taskText.trim() !== "") {
    const taskId = 'task-' + Date.now();
    const li = document.createElement('li');
    li.className = 'task-item';
    li.innerHTML = `
      <input type="checkbox" id="${taskId}">
      <label for="${taskId}">${taskText.trim()}</label>
      <span class="tag dev" data-i18n="tag_new">${translations[currentLang].tag_new}</span>
    `;
    taskList.appendChild(li);
  }
});

// Bouton Nouveau Projet
const newProjectBtn = document.getElementById('new-project-btn');
const statProjects = document.getElementById('stat-projects');

newProjectBtn.addEventListener('click', () => {
  let count = parseInt(statProjects.innerText, 10);
  statProjects.innerText = count + 1;
  alert(translations[currentLang].alert_project_created);
});
